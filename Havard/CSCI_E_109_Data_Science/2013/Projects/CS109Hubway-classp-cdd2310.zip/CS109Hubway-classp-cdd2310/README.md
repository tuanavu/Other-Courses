## CS109 Class Project ReadMe

### Team members: 
Lauren Paige Alexander

Gabriel Goulet Langlois

Joshua Michael Wolff

### Topic:
Hubway stations bike and slot availability predicition.

### Data Sources:
Hubway station status data minute by minute

Hubway trip data

Boston/Cambridge Weather data



CS109 Class Project Repository. 

